<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('category_write', function (Blueprint $table) {
            $table->uuid('category_id');
            $table->uuid('write_id');
            $table->timestamps();

            $table->primary(['category_id', 'write_id']); // Composite primary key

            // Foreign key constraints
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->foreign('write_id')->references('id')->on('writes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('category_write');
    }
};
