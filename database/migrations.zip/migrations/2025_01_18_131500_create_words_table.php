<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('words', function (Blueprint $table) {
            // UUID primary key
            $table->uuid('id')->primary();

            $table->string('word');
            $table->text('meaning');
            $table->string('type');
            $table->string('language');
            $table->integer('learning_status')->default(0);  // 0 = not learned, 1 = learning, 2 = learned
            $table->boolean('flag')->default(false);
            $table->integer('difficulty_level')->default(1); // 1 = easy, 5 = hard
            $table->integer('incorrect_count')->default(0);
            $table->integer('review_count')->default(0);
            $table->date('last_review_date')->nullable();

            // created_at & updated_at
            $table->timestamps();
        });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('words');
    }
};
