<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('word_pack_relations', function (Blueprint $table) {
            $table->uuid('id')->primary();

            $table->uuid('word_id');
            $table->foreign('word_id')->references('id')->on('words')->onDelete('cascade');

            $table->uuid('pack_id');
            $table->foreign('pack_id')->references('id')->on('language_packs')->onDelete('cascade');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('word_pack_relations');
    }
};
