<?php

namespace App\Http\Controllers\WritesCategories;

use App\Http\Controllers\Controller;
use App\Models\WritesCategories\Category;
use App\Models\WritesCategories\Write;
use App\Services\WritesCategories\CategoryService;
use App\Services\WritesCategories\WriteService;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    private $categoryService;
    private $writeService;

    private array $screenDefault = [
        'isMobileSidebar' => false,
        'name' => 'categories'
    ];

    public function __construct(CategoryService $categoryService, WriteService $writeService)
    {
        $this->categoryService = $categoryService;
        $this->writeService = $writeService;
    }

    public function index()
    {
        $categories = $this->categoryService->getCategories();
        $writes = $this->writeService->getWrites();

        return inertia('WritesCategories/Categories/IndexCategory', [
            'screen'     => [
                'isMobileSidebar' => true,
                'name'            => 'categories'
            ],
            'categories' => $categories,
            'writes'     => $writes,
        ]);
    }

    public function show($slug)
    {
        $category = Category::with('children')->where('slug', $slug)->firstOrFail();
        $categories = $this->categoryService->getCategories();

        // Mevcut kategori ve tüm alt kategorilerin ID'lerini toplama
        $categoryIds = collect([$category->id]);
        $this->getChildCategoryIds($category, $categoryIds);

        $writes = $this->writeService->getWritesByCategories($categoryIds);

        return inertia('WritesCategories/Categories/ShowCategory', [
            'category' => $category,
            'categories' => $categories,
            'writes' => $writes,
            'screen' => $this->screenDefault
        ]);
    }

    // Alt kategorilerin ID'lerini toplayan yardımcı metod
    private function getChildCategoryIds($category, &$categoryIds)
    {
        foreach ($category->children as $child) {
            $categoryIds->push($child->id);
            if ($child->children->count() > 0) {
                $this->getChildCategoryIds($child, $categoryIds);
            }
        }
    }

    public function create()
    {
        return inertia('WritesCategories/Categories/CreateCategory', [
            'screen' => $this->screenDefault
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:categories,slug',
            'description' => 'nullable|string',
        ]);

        $this->categoryService->createCategory($request->all());

        return redirect()
            ->route('categories.index')
            ->with('success', 'Kategori başarıyla oluşturuldu.');
    }

    public function edit(Category $category)
    {
        return inertia('WritesCategories/Categories/EditCategory', [
            'category' => $category,
            'screen'   => $this->screenDefault
        ]);
    }

    public function update(Request $request, Category $category)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:categories,slug,' . $category->id,
            'description' => 'nullable|string',
        ]);

        $this->categoryService->updateCategory($category, $request->all());

        return redirect()
            ->route('categories.index')
            ->with('success', 'Kategori başarıyla güncellendi.');
    }

    public function destroy(Category $category)
    {
        $this->categoryService->deleteCategory($category);

        return redirect()
            ->route('categories.index')
            ->with('success', 'Kategori başarıyla silindi.');
    }

    public function showByCategory($categorySlug, $writeSlug)
    {
        $category = Category::with('children')->where('slug', $categorySlug)->firstOrFail();
        $categories = $this->categoryService->getCategories();

        $writes = $this->writeService->getWritesByCategory($category);
        $write = $this->writeService->getWriteBySlug($writeSlug);

        return inertia('WritesCategories/Categories/WriteByCategory', [
            'category' => $category,
            'writes' => $writes,
            'write' => $write,
            'categories' => $categories,
            'screen' => $this->screenDefault
        ]);
    }
}
