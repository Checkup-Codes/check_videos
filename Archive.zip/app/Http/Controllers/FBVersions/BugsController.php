<?php

namespace App\Http\Controllers\FBVersions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BugsController extends Controller
{
    //
}
